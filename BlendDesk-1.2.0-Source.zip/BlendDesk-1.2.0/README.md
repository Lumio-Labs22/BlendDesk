# BlendDesk

Open `Windows\BlendDesk.exe` to browse your local Blender projects.

- **Add files** tracks one or more `.blend` projects. **Add folder** finds projects in that folder and its subfolders. Drag files and folders from File Explorer into the app to add them together.
- **Sources** lists the files and folders you added. **Remove source** removes the entry from BlendDesk and leaves it on disk.
- Switch between **Cards** and **List**, filter by **Favorites** or **Recently opened**, and use **Sort** to order your library. Search includes file names, folders, and notes. Press F5 to refresh or Ctrl+F to focus search.
- Select a project and choose **Details** (Ctrl+I) to view its file information, copy its path, or save local project notes.
- Cards display the scene preview saved in the project. If a file has no preview, **Generate preview** uses its active camera or frames the model automatically. Generated previews are cached separately.
- In **Settings**, choose **Clean** or **Liquid Glass**, then choose **Light**, **Dark**, or **System** under **Color mode**. Select **Done** to save. Blender is detected automatically. Use **Browse** to choose a specific executable.
- Under **Settings → Background**, select **Choose image** to preview a PNG, JPEG, or BMP file. Select **Done** to keep it or **Use default** to return to the theme background.

## Requirements

Windows x64 and .NET Desktop Runtime 10. Blender is required to open projects and generate previews.

## Build

From the `BlenderLibrary` folder with .NET SDK 10:

```powershell
dotnet publish .\src\BlenderLibrary.csproj -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -p:EnableSingleFileAnalyzer=false -p:DebugType=None -o .\Windows
```
